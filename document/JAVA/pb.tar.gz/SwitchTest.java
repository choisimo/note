/**
 * 연습 문제 2
 * 파일 이름 : SwitchTest.java
 */

import java.util.Scanner;

public class SwitchTest {
    public static void main(String[] args) 
    {
        /** 안 풀어도 됨 */
    } 
}
